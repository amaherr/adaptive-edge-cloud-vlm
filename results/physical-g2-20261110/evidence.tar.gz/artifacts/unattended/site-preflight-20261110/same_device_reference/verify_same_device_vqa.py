import argparse,pathlib,json,hashlib,datetime,sys,time
from adaptive_vlm.config import load_experiment_config,model_contract_fingerprint
from adaptive_vlm.data.manifest import load_frozen_manifest
from adaptive_vlm.determinism import seed_everything
from adaptive_vlm.artifacts import write_json_atomic,append_jsonl
from adaptive_vlm.models.moondream import MoondreamAdapter
p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--manifest',required=True);p.add_argument('--output',required=True);args=p.parse_args()
import torch
torch.cuda._device_count_nvml=lambda:-1
config=load_experiment_config(args.config);manifest=load_frozen_manifest(args.manifest);assert len(manifest.items)==100
output=pathlib.Path(args.output);output.mkdir(parents=True,exist_ok=False);(output/'features').mkdir();seed_everything(config.runtime.seed)
semantic=[{'request_id':i.request_id,'image_sha256':i.image_sha256,'prompt':i.prompt,'references':list(i.references),'scoring':i.scoring,'source':i.source,'revision':i.revision} for i in manifest.items]
semantic_sha=hashlib.sha256(json.dumps(semantic,sort_keys=True,separators=(',',':')).encode()).hexdigest()
report={'input_semantic_sha256':semantic_sha,'schema_version':1,'purpose':'Same-device full-VQA monolithic/decomposed parity; no cross-GPU token gate changes','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'model_contract_sha256':model_contract_fingerprint(config.model),'manifest_sha256':manifest.sha256,'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'device':torch.cuda.get_device_name(0),'source_files_sha256':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [pathlib.Path('src/adaptive_vlm/models/moondream.py'),pathlib.Path('src/adaptive_vlm/timing.py')]},'requests':100,'completed':0,'mismatches':0,'passed':False}
write_json_atomic(output/'status.json',report);print('Loading pinned full model for 100 same-device comparisons',flush=True)
adapter=MoondreamAdapter.from_pretrained(config.model,cache_dir='.model-cache',artifact_manifest='configs/model/moondream2_artifact.yaml',vision_device='cuda:0',text_device='cuda:0',offline=True)
for index,item in enumerate(manifest.items,1):
 print(f'[{index}/100] {item.request_id}',flush=True);request=item.to_request();reference=adapter.run_monolithic(request);candidate=adapter.run_decomposed(request);comparison=adapter.compare_runs(reference,candidate)
 data=reference.projected.tensor.detach().contiguous().cpu().view(torch.uint8).numpy().tobytes();feature=output/'features'/(item.request_id+'.bf16');feature.write_bytes(data)
 row={'request_id':item.request_id,'image_sha256':item.image_sha256,'comparison':comparison,'reference_tokens':list(reference.result.output_token_ids),'candidate_tokens':list(candidate.result.output_token_ids),'reference_text':reference.result.output_text,'candidate_text':candidate.result.output_text,'feature_sha256':hashlib.sha256(data).hexdigest(),'feature_file':str(feature.relative_to(output)),'reference_metrics':dict(reference.result.metrics),'candidate_metrics':dict(candidate.result.metrics)};append_jsonl(output/'requests.jsonl',row)
 report['completed']=index;report['mismatches']+=int(not all(comparison[k] for k in ['projected_tensor_equal','token_ids_equal','text_equal']));report['updated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();write_json_atomic(output/'status.json',report)
 del reference,candidate,data
report['passed']=report['completed']==100 and report['mismatches']==0;report['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();write_json_atomic(output/'report.json',report);write_json_atomic(output/'status.json',report);print(json.dumps(report),flush=True)
if not report['passed']:raise SystemExit(1)
